# Delete round Lambda function
