# Generate QR Lambda function package
