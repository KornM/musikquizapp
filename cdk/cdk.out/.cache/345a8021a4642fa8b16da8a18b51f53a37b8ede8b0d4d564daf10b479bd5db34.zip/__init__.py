# Register participant Lambda function package
