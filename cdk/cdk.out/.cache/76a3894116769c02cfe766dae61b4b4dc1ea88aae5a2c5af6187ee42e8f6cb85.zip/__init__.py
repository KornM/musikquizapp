"""Admin login Lambda function package."""
