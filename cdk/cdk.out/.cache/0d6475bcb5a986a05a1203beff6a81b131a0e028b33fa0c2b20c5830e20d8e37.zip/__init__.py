# Submit answer Lambda function
