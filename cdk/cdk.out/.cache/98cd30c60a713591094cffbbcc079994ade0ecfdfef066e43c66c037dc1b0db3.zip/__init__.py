# Reset points Lambda function
