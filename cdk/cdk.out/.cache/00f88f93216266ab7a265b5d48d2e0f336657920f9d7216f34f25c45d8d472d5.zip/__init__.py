# Create quiz Lambda function package
