# Get scoreboard Lambda function
