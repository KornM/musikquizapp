# Start round Lambda function
