# Clear participants Lambda function
