# Delete session Lambda function package
