# Get audio Lambda function package
