# Get quiz Lambda function package
